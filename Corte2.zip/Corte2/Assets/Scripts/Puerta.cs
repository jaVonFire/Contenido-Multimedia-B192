using UnityEngine;
public class Puerta : ObjetoInteractivo
{
    public override void Interactuar()
    {
        Debug.Log("La puerta se abre");
    }
}