using UnityEngine;
public class Cofre : ObjetoInteractivo
{
    public override void Interactuar()
    {
        Debug.Log("Has obtenido un objeto");
    }
}