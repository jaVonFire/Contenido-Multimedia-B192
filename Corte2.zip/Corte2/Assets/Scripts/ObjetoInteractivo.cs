using UnityEngine;
public class ObjetoInteractivo : MonoBehaviour
{
    public string nombreObjeto;
    public virtual void Interactuar()
    {
        Debug.Log("Interacci�n gen�rica con " + nombreObjeto);
    }
}