using UnityEngine;

public class MovimientoSimple : MonoBehaviour
{
    public float velocidad = 5f;
    CharacterController controller;

    void Start()
    {
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");
        Vector3 move = transform.right * x + transform.forward * z;
        controller.Move(move * velocidad * Time.deltaTime);
    }
}