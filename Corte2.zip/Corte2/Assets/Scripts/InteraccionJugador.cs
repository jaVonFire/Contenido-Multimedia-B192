using UnityEngine;

public class InteraccionJugador : MonoBehaviour
{
    public float distancia = 5f;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            // Raycast desde el centro de la pantalla (mirada)
            Ray ray = Camera.main.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
            if (Physics.Raycast(ray, out RaycastHit hit, distancia))
            {
                ObjetoInteractivo obj = hit.collider.GetComponent<ObjetoInteractivo>();
                if (obj != null)
                {
                    obj.Interactuar();
                }
            }
        }
    }
}