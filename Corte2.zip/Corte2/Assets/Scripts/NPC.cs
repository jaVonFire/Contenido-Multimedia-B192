using UnityEngine;
public class NPC : ObjetoInteractivo
{
    public override void Interactuar()
    {
        Debug.Log("El NPC dice: �Hola!");
    }
}